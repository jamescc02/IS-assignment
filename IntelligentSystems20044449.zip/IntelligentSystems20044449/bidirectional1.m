%This is a Bidirectional Long Short Term Memory neural network model built on human activity recognition
%through a single wrist-worn accelerometer.

%The following code requires the Deep Learning Toolbox and Parallel
%Computing Toolbox in order to process and run the model

%Here I have loaded the accelerometer data matlab files into the editor.
%And I have assigned them into variables.
c1 = load("subject102.mat");
c2 = load("subject105.mat");
c3 = load("subject104.mat");
c4 = load("subject107.mat");

%Here I am grabbing the values from positions 2 and 4 from variable c1 and
%placing it into a new variable c1X. This represents the axis of
%accelerometer data which are 'x', 'y' and 'z'.
c1X = c1.data(:,2:4)';
%Here I am doing the same but placing the activityID into the c1Y variable.
c1Y = c1.data(:,5)';
%The single straight quote ' means transpose. This allows the model to
%transpose a matrix from 'V x C x V' as the BiLSTM only realises the input
%feature by timestep format. Here the 'V' is the value of each time step,
%and 'C'means the channel (x,y,z)
%The find command will extract the index of those activites.
%Sitting
c1FilterIdx = find(c1Y == 2 | c1Y==4 | c1Y == 5 | c1Y==6);
c1X=c1X(:, c1FilterIdx);
c1Y=c1Y(c1FilterIdx);

%We have done the same process with the variable c2. Because there are 4
%categories in total: sitting, wallking, running and, cycling.
%Walking
c2X = c2.data(:,2:4)';
c2Y = c2.data(:,5)';
c2FilterIdx = find(c2Y == 2 | c2Y==4 | c2Y == 5 | c2Y==6);
c2X=c2X(:, c2FilterIdx);
c2Y=c2Y(c2FilterIdx);

%Running
c3X = c3.data(:,2:4)';
c3Y = c3.data(:,5)';
c3FilterIdx = find(c3Y == 2 | c3Y==4 | c3Y == 5 | c3Y==6);
c3X=c3X(:, c3FilterIdx);
c3Y=c3Y(c3FilterIdx);

%Cycling
c4X = c4.data(:,2:4)';
c4Y = c4.data(:,5)';
c4FilterIdx = find(c4Y == 2 | c4Y==4 | c4Y == 5 | c4Y==6);
c4X=c4X(:, c4FilterIdx);
c4Y=c4Y(c4FilterIdx);

%Here we are going to display the unique labels for each category and check
%how many training values there are.
%The function countEachLabel will calculate the number of samples or values
%there are in each category, then we will display this to the screen and
%check the label distribution.
disp(countlabels(c1Y));
disp(countlabels(c2Y));
disp(countlabels(c3Y));
disp(countlabels(c4Y));

%Defining the class number variable and the class name variable.
lstm_class = [2 4 5 6];
lstm_class_name = ["sitting" "walking" "running" "cycling"];

%Here we are plotting the data. We are using the figure command to loop
%through each activity to get the corresponding class number.
%We then get the activity index by using the label vector to plot them on
%the figure.
%The x-axis label is set to time step and the y-axis label is set to
%acceleration
%The figure's title is set to Training Sequence, Feature and a legend is
%added so I can observe the difference between activites.
figure
for k = 1:numel(lstm_class)
    label = lstm_class(k);
    idx = find(c1Y == label);
    hold on
    plot(idx, c1X(1, idx));
end
hold off

xlabel("Time Step")
ylabel("Acceleration")
title("Training Sequence, Feature")
legend(lstm_class_name, 'Location', 'northwest')

%Here we are creating a figure for running. The class number is five, so we
%get the running signal and visualse it. We use the find function to get
%all the indexes and then filter the first 500 samples from the x-axis.
%Then we plot them on the figure.
figure
running_idx = find(c1Y == 5);
running_idx = running_idx(1, 1:500);
running_x = c1X(1, running_idx);
plot(running_x)
xlabel("Time Step")
ylabel("Acceleration")
title("Training Sequence 1, X axis for running")

%The same is done here for walking
figure
walking_idx = find(c1Y == 4);
walking_idx = walking_idx(1, 1:500);
walking_x = c1X(1, walking_idx);
plot(walking_x)
xlabel("Time Step")
ylabel("Acceleration")
title("Training Sequence 1, X axis for walking")

%The same is done here for sitting
figure
sitting_idx = find(c1Y == 2);
sitting_idx = sitting_idx(1, 1:500);
sitting_x = c1X(1, sitting_idx);
plot(sitting_x)
xlabel("Time Step")
ylabel("Acceleration")
title("Training Sequence 1, X axis for sitting")

%The same is done here for cycling
figure
cycling_idx = find(c1Y == 6);
cycling_idx = cycling_idx(1, 1:500);
cycling_x = c1X(1, cycling_idx);
plot(cycling_x)
xlabel("Time Step")
ylabel("Acceleration")
title("Training Sequence 1, X axis for cycling")

%Converting the ground truth vectors into categorical variables
lstm_class = categorical(lstm_class);
lstm_class_name = categorical(lstm_class_name);

c1Y = categorical(c1Y);
c2Y = categorical(c2Y);
c3Y = categorical(c3Y);
c4Y = categorical(c4Y);

%Normalisation - Z-score method is used to normalise the data into a normal
%distribution. We first calculate the mean value and standard derivation
%for each axis by specifiying the dimension index number.
%We then minus each dimension's data from their mean and divided by the
%standard deviation.
c1X = (c1X - mean(c1X, 2))./std(c1X, 0, 2);
c2X = (c2X - mean(c2X, 2))./std(c2X, 0, 2);
c3X = (c3X - mean(c3X, 2))./std(c3X, 0, 2);
c4X = (c4X - mean(c4X, 2))./std(c4X, 0, 2);

%The training of the testing dataset in the cell data format
XTrain = {c1X, c3X};
YTrain = {c1Y, c3Y};
XVal = {c4X};
YVal = {c4Y};

XTest = {c2X};
YTest = {c2Y};

%The dimension of input data contains three axes (x,y,z), The hidden unit size for
%the cells is 256 and the number of classes for the activites is 4.
%(Categories)
numberFeatures = 3;
numberHiddenUnits = 256;
numberClasses = 4;

%First I added the sequential input layer and specified the input dimension
%number. Next, I add a bidirectional LSTM layer which will process the sequence in both directions and set the output model to sequence.
%This means that I am predicting each data sample in the sequence. Next,
%there is a fully connected layer, a softmax layer which converts the
%outputs of the FC layer into probability. The classification layer can
%take the probability and output the predicted class.
layers = [sequenceInputLayer(numberFeatures)
    bilstmLayer(numberHiddenUnits,'OutputMode','sequence')
    fullyConnectedLayer(numberClasses)
    softmaxLayer
    classificationLayer];

%The training option for the Bidirectional LSTM model is the 'adam' optimiser. Which is
%used for the gradient decent training. The Max epochs is set to 20 and the
%batch size is set to 64. The gradient threshold is used to control the
%gradient training process. If the gradient exceeds the value of
%GradientThreshold, then the gradient is clipped according to the
%GradientThresholdMethod training option. Once the training option is
%defined, then I can start the training process. After the training process
%is completed, I can use the classify function to make a prediction on the
%test dataset and calculate the accuracy of the predictions.
options = trainingOptions('adam', ...
    'MaxEpochs',20, ...
    'GradientThreshold',2, ...
    'Verbose',0, ...
    'Plots','training-progress', ...
    'MiniBatchSize', 64, ...
    'InitialLearnRate', 0.001, ...
    ValidationData={XVal,YVal}, ...
    ValidationFrequency=10);

net = trainNetwork(XTrain,YTrain,layers,options);

%Test data is then calculated and displayed using the figure function
figure
plot(XTest{1}');
xlabel("Time Step")
legend("Feature" + (1:numberFeatures))
title("Test Data")

YPred = classify(net, XTest);

acc = sum(YPred{1} == YTest{1})./numel(YTest{1});
disp(['Prediction accuracy: ', num2str(acc * 100), '%']);

%Once the accuracy calculation is completed, in the next step, The ground
%truth labels and the predicted physical activity are plotted.
figure
plot(YPred{1}, '.-')
hold on
plot(YTest{1})
hold off

xlabel("Time Step")
ylabel("Activity")
title("Predicted Activites")
legend(["Predicted" "Test Data"])
